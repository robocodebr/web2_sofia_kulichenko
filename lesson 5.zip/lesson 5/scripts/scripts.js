alert("net");
let f = prompt("say", "f");
console.log(f+f+f);
let a = confirm("chto"); 
console.log(a);